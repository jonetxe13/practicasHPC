./gen_workloads 50 50 1 1 64 50 50 sequential random cached 100 1 100
