#ifndef _trace
#define _trace

void read_trc(application *app);

void read_fsin_trc(application *app);

void read_alog_trc(application *app);

#endif
