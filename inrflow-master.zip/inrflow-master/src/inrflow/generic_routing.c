/*
 * =====================================================================================
 *
 *       Filename:  generic_routing.c
 *
 *    Description:  Descriptionr
 *
 *        Version:  1.0
 *        Created:  07/08/16 08:06:11
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Jose A. Pascual (), joseantonio.pascual@ehu.es
 *   Organization:  University of the Basque Country UPV/EHU
 *
 * =====================================================================================
 */


